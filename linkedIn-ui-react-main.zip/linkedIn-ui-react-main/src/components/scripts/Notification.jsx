export const Notification = () => {
  return (
    <>
      <h4>this is Notification page I created it leter</h4>
      <h4>this is Notification page I created it leter</h4>
    </>
  );
};
