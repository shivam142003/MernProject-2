export const MyNetwork = () => {
  return (
    <>
      <h4>This is MyNetwork Page I created it leter</h4>
    </>
  );
};
