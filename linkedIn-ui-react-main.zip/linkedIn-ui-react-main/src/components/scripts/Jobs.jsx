export const Jobs = () => {
  return (
    <>
      <h4>This is jobs Page I created it leter</h4>
    </>
  );
};
