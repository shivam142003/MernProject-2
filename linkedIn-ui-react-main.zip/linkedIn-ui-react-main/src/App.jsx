import './App.css';
import { AllRouters } from './components/routers.jsx/routers';

function App() {
  return (
    <div className="container">
        <AllRouters />
    </div>
  );
}

export default App;
